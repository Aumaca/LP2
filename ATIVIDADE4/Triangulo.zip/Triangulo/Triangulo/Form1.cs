﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtA_Validated(object sender, EventArgs e)
        {
            ParaConfigurarErro(errorProvA, txtA);
        }

        private void TxtB_Validated(object sender, EventArgs e)
        {
            ParaConfigurarErro(errorProvB, txtB);
        }

        private void TxtC_Validated(object sender, EventArgs e)
        {
            ParaConfigurarErro(errorProvC, txtC);
        }

        private void ParaConfigurarErro(ErrorProvider errorProv, TextBox txt)
        {
            double valorNovo;
            errorProv.SetError(txt, "");

            if (!Double.TryParse(txt.Text, out valorNovo))
            {
                errorProv.SetError(txt, "Inválido.");
            }
        }

        private bool TrianguloEValido(double valA, double valB, double valC)
        {            
            if ((valB - valC) < valA && valA < valB + valC) {
                return true;
            }
            else if ((valA - valC) < valB && valB < valA + valC) {
                return true;
            }
            else if ((valA - valB) < valC && valC < valA + valB) {
                return true;
            }
            else {
                return false;
            }
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            double valA, valB, valC;

            try
            {
                valA = Convert.ToDouble(txtA.Text);
                valB = Convert.ToDouble(txtB.Text);
                valC = Convert.ToDouble(txtC.Text);

                if (!TrianguloEValido(valA, valB, valC))
                {
                    MessageBox.Show("Os valores não compõem um triângulo válido.");
                }
                else if (valA == valB && valA == valC && valB == valC)
                {
                    txtTipoTriangulo.Text = "Equilátero";
                }
                else if (
                    (valA == valB && valC != valA) ||
                    (valA == valC && valB != valA) ||
                    (valB == valC && valA != valB)
                )
                {
                    txtTipoTriangulo.Text = "Isósceles";
                }
                else
                {
                    txtTipoTriangulo.Text = "Escaleno";
                }
            }
            catch
            {
                MessageBox.Show("Valors inválidos.");
            }
        }
    }
}

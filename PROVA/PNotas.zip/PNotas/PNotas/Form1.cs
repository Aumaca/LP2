﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            char[,] alunos = new char[6, 10];
            char[] gabarito = { 'A', 'B', 'D', 'E', 'C', 'D', 'A', 'E', 'D', 'B' };

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string auxiliar = Interaction.InputBox($"Aluno {i + 1}\nQuestão {j + 1}: ");
                    char auxiliarChar;

                    if (char.TryParse(auxiliar.ToUpper(), out auxiliarChar))
                    {
                        if (auxiliarChar >= 'A' && auxiliarChar <= 'E')
                        {
                            alunos[i, j] = auxiliarChar;
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida. Tente novamente.");
                            j--;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida. Tente novamente.");
                        j--;
                    }
                }
            }

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string exibir = "";
                    if (alunos[i, j] == gabarito[j])
                    {
                        exibir += $"O aluno {i + 1} acertou a questão {j + 1}. Era {gabarito[j]} e escolheu {alunos[i, j]}.\n";
                    }
                    else
                    {
                        exibir += $"O aluno {i + 1} errou a questão {j + 1}. Era {gabarito[j]} mas escolheu {alunos[i, j]}.\n";
                    }
                    lstBx.Items.Add(exibir);
                }
            }
        }
    }
}

﻿namespace IMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlForm = new Panel();
            txtGrau = new TextBox();
            lblGrau = new Label();
            txtClassificacao = new TextBox();
            lblClassificacao = new Label();
            txtIMC = new TextBox();
            lblIMC = new Label();
            btnCalcular = new Button();
            txtAltura = new TextBox();
            txtPeso = new TextBox();
            lblAltura = new Label();
            lblPeso = new Label();
            lblTitulo = new Label();
            pnlForm.SuspendLayout();
            SuspendLayout();
            // 
            // pnlForm
            // 
            pnlForm.BackColor = Color.DarkTurquoise;
            pnlForm.Controls.Add(txtGrau);
            pnlForm.Controls.Add(lblGrau);
            pnlForm.Controls.Add(txtClassificacao);
            pnlForm.Controls.Add(lblClassificacao);
            pnlForm.Controls.Add(txtIMC);
            pnlForm.Controls.Add(lblIMC);
            pnlForm.Controls.Add(btnCalcular);
            pnlForm.Controls.Add(txtAltura);
            pnlForm.Controls.Add(txtPeso);
            pnlForm.Controls.Add(lblAltura);
            pnlForm.Controls.Add(lblPeso);
            pnlForm.Controls.Add(lblTitulo);
            pnlForm.Location = new Point(0, -1);
            pnlForm.Name = "pnlForm";
            pnlForm.Size = new Size(341, 349);
            pnlForm.TabIndex = 0;
            // 
            // txtGrau
            // 
            txtGrau.Location = new Point(182, 283);
            txtGrau.Multiline = true;
            txtGrau.Name = "txtGrau";
            txtGrau.Size = new Size(100, 23);
            txtGrau.TabIndex = 11;
            // 
            // lblGrau
            // 
            lblGrau.AutoSize = true;
            lblGrau.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblGrau.ForeColor = Color.White;
            lblGrau.Location = new Point(30, 283);
            lblGrau.Name = "lblGrau";
            lblGrau.Size = new Size(146, 21);
            lblGrau.TabIndex = 10;
            lblGrau.Text = "Grau de Obesidade:";
            // 
            // txtClassificacao
            // 
            txtClassificacao.Location = new Point(182, 243);
            txtClassificacao.Multiline = true;
            txtClassificacao.Name = "txtClassificacao";
            txtClassificacao.Size = new Size(100, 23);
            txtClassificacao.TabIndex = 9;
            // 
            // lblClassificacao
            // 
            lblClassificacao.AutoSize = true;
            lblClassificacao.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblClassificacao.ForeColor = Color.White;
            lblClassificacao.Location = new Point(75, 243);
            lblClassificacao.Name = "lblClassificacao";
            lblClassificacao.Size = new Size(101, 21);
            lblClassificacao.TabIndex = 8;
            lblClassificacao.Text = "Classificação:";
            // 
            // txtIMC
            // 
            txtIMC.Location = new Point(182, 202);
            txtIMC.Multiline = true;
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(100, 23);
            txtIMC.TabIndex = 7;
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblIMC.ForeColor = Color.White;
            lblIMC.Location = new Point(105, 202);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(71, 21);
            lblIMC.TabIndex = 6;
            lblIMC.Text = "Seu IMC:";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(235, 87);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(67, 65);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular IMC";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(112, 129);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(100, 23);
            txtAltura.TabIndex = 4;
            // 
            // txtPeso
            // 
            txtPeso.Location = new Point(112, 87);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new Size(100, 23);
            txtPeso.TabIndex = 3;
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblAltura.ForeColor = Color.White;
            lblAltura.Location = new Point(30, 127);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(83, 21);
            lblAltura.TabIndex = 2;
            lblAltura.Text = "Altura (m):";
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblPeso.ForeColor = Color.White;
            lblPeso.Location = new Point(30, 87);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(76, 21);
            lblPeso.TabIndex = 1;
            lblPeso.Text = "Peso (kg):";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Georgia", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            lblTitulo.ForeColor = Color.White;
            lblTitulo.Location = new Point(30, 10);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(286, 31);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Calculadora de IMC";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(341, 346);
            Controls.Add(pnlForm);
            Name = "Form1";
            Text = "Form1";
            pnlForm.ResumeLayout(false);
            pnlForm.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlForm;
        private Label lblTitulo;
        private TextBox txtIMC;
        private Label lblIMC;
        private Button btnCalcular;
        private TextBox txtAltura;
        private TextBox txtPeso;
        private Label lblAltura;
        private Label lblPeso;
        private TextBox txtGrau;
        private Label lblGrau;
        private TextBox txtClassificacao;
        private Label lblClassificacao;
    }
}
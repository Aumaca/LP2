﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com o número {i + 1}: ", "Entrada de Dados");
                if (auxiliar == "")
                    return;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach(int x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);

        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            Double[] medias = new double[20];
            string auxiliar;
            Double media;

            for (int i = 0; i < 20; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Aluno {i + 1}\nNota {j + 1}: ");
                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Número inválido. Tente Novamente.");
                        j--;
                    }
                    else
                        media += notas[i, j];
                }

                medias[i] = media / 3;
            }

            auxiliar = "";
            for(int i = 0; i < 20; i++)
                auxiliar += $"Aluno {i+1}: {medias[i].ToString("N2")} \n";

            MessageBox.Show(auxiliar);
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            string[] alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
                "Leonardo", "Jose", "Nelma", "Tobby"};
            string auxiliar = "";
            ArrayList alunosList = new ArrayList();
            foreach (string aluno in alunos)
            {
                alunosList.Add(aluno);
                auxiliar += aluno + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}

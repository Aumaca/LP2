﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FormExercicio3 : Form
    {
        public FormExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRemover1_Click(object sender, EventArgs e)
        {
            string texto1 = txtPalavra1.Text;
            string texto2 = txtPalavra2.Text;
            int pos = texto2.IndexOf(texto1);

            while (pos >= 0)
            {
                texto2 = texto2.Substring(0, pos) + texto2.Substring(pos + texto1.Length);
                pos = texto2.IndexOf(texto1);
            }

            txtPalavra2.Text = texto2;
        }

        private void btnRemover2_Click(object sender, EventArgs e)
        {
            string texto1 = txtPalavra1.Text;
            string texto2 = txtPalavra2.Text;
            texto2 = texto2.Replace(texto1, string.Empty);
            txtPalavra2.Text = texto2;
        }

        private void BtnInverter_Click(object sender, EventArgs e)
        {
            string texto1 = txtPalavra1.Text;
            char[] caracteres = texto1.ToCharArray(); 
            Array.Reverse(caracteres);
            string textoInvertido = new string(caracteres);
            txtPalavra1.Text = textoInvertido;
        }

    }
}
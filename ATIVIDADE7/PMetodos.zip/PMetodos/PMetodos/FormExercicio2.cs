﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FormExercicio2 : Form
    {
        public FormExercicio2()
        {
            InitializeComponent();
        }

        private void BtnComparar_Click(object sender, EventArgs e)
        {
            if(String.Compare(txtTxt1.Text, txtTxt2.Text, true) == 0)
            {
                txtResultado.Text = "Iguais";
            }
            else
            {
                txtResultado.Text = "Diferentes";
            }
        }

        private void BtnInserir1_Click(object sender, EventArgs e)
        {
            int meio = txtTxt2.Text.Length / 2;
            string comeco = txtTxt2.Text.Substring(0, meio);
            string fim = txtTxt2.Text.Substring(meio, txtTxt2.Text.Length - meio);
            txtResultado.Text = comeco + txtTxt1.Text + fim;
        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            int tamanho = txtTxt1.Text.Length;
            txtTxt2.Text = txtTxt1.Text.Insert(tamanho / 2, "**");
        }
    }
}

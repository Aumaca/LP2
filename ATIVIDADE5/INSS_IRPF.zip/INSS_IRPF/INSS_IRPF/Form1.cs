﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSS_IRPF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            string nomeFunc;
            double salBruto, salLiq, salFamilia, aliqINSS, aliqIRPF, descINSS, descIRPF;
            int numFilhos;

            nomeFunc = mskbxNomeFunc.Text;
            salBruto = Convert.ToDouble(mskbxSalBruto.Text.Trim().Replace("R$", "").Replace(".", ""));
            numFilhos = Convert.ToInt16(mskbxNumFilhos.Text.Trim());

            // Alíquota INSS
            if (salBruto <= 800.47)
            {
                aliqINSS = 0.0765;
                descINSS = salBruto * aliqINSS;
            }
            else if (salBruto <= 1050)
            {
                aliqINSS = 0.0865;
                descINSS = salBruto * aliqINSS;
            }
            else if (salBruto <= 1400.77)
            {
                aliqINSS = 0.09;
                descINSS = salBruto * aliqINSS;
            }
            else
            {
                aliqINSS = 0.11;
                descINSS = 308.17;
            }

            // Alíquota IRPF
            if (salBruto <= 1257.12)
            {
                aliqIRPF = 0;
            }
            else if (salBruto <= 2512.08)
            {
                aliqIRPF = 0.15;
            }
            else
            {
                aliqIRPF = 0.275;
            }
            descIRPF = salBruto * aliqIRPF;

            // Salário Família
            if (salBruto <= 435.52)
            {
                salFamilia = 22.33 * numFilhos;
            }
            else if (salBruto <= 654.61)
            {
                salFamilia = 15.74 * numFilhos;
            }
            else
            {
                salFamilia = 0;
            }

            // Salário Líquido
            salLiq = salBruto - descINSS - descIRPF + salFamilia;

            if (aliqINSS == 0.11)
            {
                mskbxAliqINSS.Text = "Teto";
            }
            else
            {
                mskbxAliqINSS.Text = aliqINSS * 100 + "%";
            }

            mskbxAliqIRPF.Text = aliqIRPF * 100 + "%";
            mskbxDescINSS.Text = "R$" + descINSS.ToString("N2");
            mskbxDescIRPF.Text = "R$" + descIRPF.ToString("N2");
            mskbxSalFamilia.Text = "R$" + salFamilia.ToString("N2");
            mskbxSalLiq.Text = "R$" + salLiq.ToString("N2");
        }
    }
}

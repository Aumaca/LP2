﻿namespace Triangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblValA = new System.Windows.Forms.Label();
            this.lblValB = new System.Windows.Forms.Label();
            this.lblValC = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.errorProvA = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvC = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtTipoTriangulo = new System.Windows.Forms.TextBox();
            this.lblTipoTriangulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvC)).BeginInit();
            this.SuspendLayout();
            // 
            // lblValA
            // 
            this.lblValA.AutoSize = true;
            this.lblValA.Location = new System.Drawing.Point(45, 33);
            this.lblValA.Name = "lblValA";
            this.lblValA.Size = new System.Drawing.Size(87, 20);
            this.lblValA.TabIndex = 0;
            this.lblValA.Text = "Valor de A:";
            // 
            // lblValB
            // 
            this.lblValB.AutoSize = true;
            this.lblValB.Location = new System.Drawing.Point(45, 76);
            this.lblValB.Name = "lblValB";
            this.lblValB.Size = new System.Drawing.Size(87, 20);
            this.lblValB.TabIndex = 1;
            this.lblValB.Text = "Valor de B:";
            // 
            // lblValC
            // 
            this.lblValC.AutoSize = true;
            this.lblValC.Location = new System.Drawing.Point(45, 124);
            this.lblValC.Name = "lblValC";
            this.lblValC.Size = new System.Drawing.Size(87, 20);
            this.lblValC.TabIndex = 2;
            this.lblValC.Text = "Valor de C:";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(139, 33);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(100, 26);
            this.txtA.TabIndex = 3;
            this.txtA.Validated += new System.EventHandler(this.TxtA_Validated);
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(138, 76);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(100, 26);
            this.txtB.TabIndex = 4;
            this.txtB.Validated += new System.EventHandler(this.TxtB_Validated);
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(138, 121);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 26);
            this.txtC.TabIndex = 5;
            this.txtC.Validated += new System.EventHandler(this.TxtC_Validated);
            // 
            // errorProvA
            // 
            this.errorProvA.ContainerControl = this;
            // 
            // errorProvB
            // 
            this.errorProvB.ContainerControl = this;
            // 
            // errorProvC
            // 
            this.errorProvC.ContainerControl = this;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(83, 184);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(118, 35);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // txtTipoTriangulo
            // 
            this.txtTipoTriangulo.Location = new System.Drawing.Point(185, 256);
            this.txtTipoTriangulo.Name = "txtTipoTriangulo";
            this.txtTipoTriangulo.Size = new System.Drawing.Size(100, 26);
            this.txtTipoTriangulo.TabIndex = 8;
            // 
            // lblTipoTriangulo
            // 
            this.lblTipoTriangulo.AutoSize = true;
            this.lblTipoTriangulo.Location = new System.Drawing.Point(45, 259);
            this.lblTipoTriangulo.Name = "lblTipoTriangulo";
            this.lblTipoTriangulo.Size = new System.Drawing.Size(134, 20);
            this.lblTipoTriangulo.TabIndex = 7;
            this.lblTipoTriangulo.Text = "Tipo do Triângulo:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 450);
            this.Controls.Add(this.txtTipoTriangulo);
            this.Controls.Add(this.lblTipoTriangulo);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblValC);
            this.Controls.Add(this.lblValB);
            this.Controls.Add(this.lblValA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValA;
        private System.Windows.Forms.Label lblValB;
        private System.Windows.Forms.Label lblValC;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.ErrorProvider errorProvA;
        private System.Windows.Forms.ErrorProvider errorProvB;
        private System.Windows.Forms.ErrorProvider errorProvC;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtTipoTriangulo;
        private System.Windows.Forms.Label lblTipoTriangulo;
    }
}


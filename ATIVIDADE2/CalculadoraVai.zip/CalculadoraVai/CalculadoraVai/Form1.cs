﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraVai
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double numero1, numero2;

        private void DoOperation(char signal)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("numero 1 invalido");
                txtNum1.Focus();
            }
            else if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("numero 2 invalido");
                txtNum2.Focus();
            }
            else
            {
                switch (signal)
                {
                    case '+':
                        txtResultado.Text = (numero1 + numero2).ToString();
                        break;
                    case '-':
                        txtResultado.Text = (numero1 - numero2).ToString();
                        break;
                    case '*':
                        txtResultado.Text = (numero1 * numero2).ToString();
                        break;
                    case '/':
                        txtResultado.Text = (numero1 / numero2).ToString();
                        break;
                }
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            DoOperation('+');
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            DoOperation('-');
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            DoOperation('*');
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por 0.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
            } else
            {
                DoOperation('/');
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResultado.Text = "";
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}

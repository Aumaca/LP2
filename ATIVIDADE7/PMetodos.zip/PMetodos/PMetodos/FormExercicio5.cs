﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FormExercicio5 : Form
    {
        public FormExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSortear_Click(object sender, EventArgs e)
        {
            int num1;
            int num2;
            int novoNum;
            bool tentativa1 = int.TryParse(txtNumero1.Text, out num1);
            bool tentativa2 = int.TryParse(txtNumero2.Text, out num2);

            if (tentativa1 && tentativa2)
            {
                if (num1 < 0 || num2 < 0)
                {
                    MessageBox.Show("Números devem ser maiores ou igual a 0.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (num1 > num2)
                {
                    MessageBox.Show("Número 1 deve ser maior que número 2.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Random rand = new Random();
                    novoNum = rand.Next(num1, num2);
                    txtResultado.Text = novoNum.ToString();
                }
            }
            else
            {
                MessageBox.Show("Dados inválidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            int i = 0;
            string auxiliar = "s";
            ArrayList nomes = new ArrayList();
            ArrayList comps = new ArrayList();

            while (auxiliar != "")
            {
                auxiliar = Interaction.InputBox($"Nome {i+1}: ", "Entrada de Dados");
                if (!auxiliar.Replace(" ", "").All(char.IsLetter))
                {
                    MessageBox.Show("Nome inválido.");
                    i--;
                }
                else
                {
                    int comp = auxiliar.Replace(" ", "").Length;
                    nomes.Add(auxiliar);
                    comps.Add(comp);
                    lstResultado.Items.Add($"Nome {auxiliar} tem {comp} caracteres.");
                }
                i++;
            }
        }
    }
}

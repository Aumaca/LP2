﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FormExercicio4 : Form
    {
        public FormExercicio4()
        {
            InitializeComponent();
        }

        private void BtnContarNum_Click(object sender, EventArgs e)
        {
            int numeros = 0;
            for (int i = 0; i < richTextFrase.Text.Length; i++)
            {
                if (Char.IsNumber(richTextFrase.Text[i])) {
                    numeros++;
                }
            }
            txtResultado.Text = numeros.ToString();
        }

        private void BtnPrimeiroEsp_Click(object sender, EventArgs e)
        {
            int i = 0;
            while (i < richTextFrase.Text.Length)
            {
                if (Char.IsWhiteSpace(richTextFrase.Text[i]))
                {
                    i++;
                    txtResultado.Text = i.ToString();
                    break;
                }
                i++;
            }
        }

        private void BtnLetras_Click(object sender, EventArgs e)
        {
            int letras = 0;
            foreach(char caracter in richTextFrase.Text)
            {
                if (Char.IsLetter(caracter))
                {
                    letras++;
                }
            }
            txtResultado.Text = letras.ToString();
        }
    }
}

﻿namespace PMetodos
{
    partial class FormExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInserir2 = new System.Windows.Forms.Button();
            this.btnInserir1 = new System.Windows.Forms.Button();
            this.btnContarNum = new System.Windows.Forms.Button();
            this.lblTxt1 = new System.Windows.Forms.Label();
            this.richTextFrase = new System.Windows.Forms.RichTextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.labelResul = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInserir2
            // 
            this.btnInserir2.Location = new System.Drawing.Point(294, 170);
            this.btnInserir2.Name = "btnInserir2";
            this.btnInserir2.Size = new System.Drawing.Size(113, 60);
            this.btnInserir2.TabIndex = 4;
            this.btnInserir2.Text = "Contar Letras";
            this.btnInserir2.UseVisualStyleBackColor = true;
            this.btnInserir2.Click += new System.EventHandler(this.BtnLetras_Click);
            // 
            // btnInserir1
            // 
            this.btnInserir1.Location = new System.Drawing.Point(151, 170);
            this.btnInserir1.Name = "btnInserir1";
            this.btnInserir1.Size = new System.Drawing.Size(113, 60);
            this.btnInserir1.TabIndex = 3;
            this.btnInserir1.Text = "Primeiro espaço";
            this.btnInserir1.UseVisualStyleBackColor = true;
            this.btnInserir1.Click += new System.EventHandler(this.BtnPrimeiroEsp_Click);
            // 
            // btnContarNum
            // 
            this.btnContarNum.Location = new System.Drawing.Point(19, 170);
            this.btnContarNum.Name = "btnContarNum";
            this.btnContarNum.Size = new System.Drawing.Size(113, 60);
            this.btnContarNum.TabIndex = 2;
            this.btnContarNum.Text = "Contar Números";
            this.btnContarNum.UseVisualStyleBackColor = true;
            this.btnContarNum.Click += new System.EventHandler(this.BtnContarNum_Click);
            // 
            // lblTxt1
            // 
            this.lblTxt1.AutoSize = true;
            this.lblTxt1.Location = new System.Drawing.Point(35, 34);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.Size = new System.Drawing.Size(52, 20);
            this.lblTxt1.TabIndex = 9;
            this.lblTxt1.Text = "Texto:";
            // 
            // richTextFrase
            // 
            this.richTextFrase.Location = new System.Drawing.Point(39, 58);
            this.richTextFrase.Name = "richTextFrase";
            this.richTextFrase.Size = new System.Drawing.Size(368, 96);
            this.richTextFrase.TabIndex = 1;
            this.richTextFrase.Text = "";
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(39, 287);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(368, 26);
            this.txtResultado.TabIndex = 5;
            // 
            // labelResul
            // 
            this.labelResul.AutoSize = true;
            this.labelResul.Location = new System.Drawing.Point(35, 264);
            this.labelResul.Name = "labelResul";
            this.labelResul.Size = new System.Drawing.Size(86, 20);
            this.labelResul.TabIndex = 18;
            this.labelResul.Text = "Resultado:";
            // 
            // FormExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelResul);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.richTextFrase);
            this.Controls.Add(this.btnInserir2);
            this.Controls.Add(this.btnInserir1);
            this.Controls.Add(this.btnContarNum);
            this.Controls.Add(this.lblTxt1);
            this.Name = "FormExercicio4";
            this.Text = "FormExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInserir2;
        private System.Windows.Forms.Button btnInserir1;
        private System.Windows.Forms.Button btnContarNum;
        private System.Windows.Forms.Label lblTxt1;
        private System.Windows.Forms.RichTextBox richTextFrase;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label labelResul;
    }
}
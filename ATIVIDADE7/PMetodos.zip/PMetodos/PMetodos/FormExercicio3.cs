﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FormExercicio3 : Form
    {
        public FormExercicio3()
        {
            InitializeComponent();
        }

        private void BtnComparar_Click(object sender, EventArgs e)
        {
            int pos = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            while (pos >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, pos) + txtPalavra2.Text.Substring(pos + txtPalavra1.Text.Length, txtPalavra2.Text.Length - pos - txtPalavra1.Text.Length);
            }
        }
    }
}
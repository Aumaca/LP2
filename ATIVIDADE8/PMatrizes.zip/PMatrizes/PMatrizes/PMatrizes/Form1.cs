﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {

        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            Double[] medias = new double[20];
            string auxiliar;
            Double media;

            for (int i = 0; i < 20; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Aluno {i + 1}\nNota {j + 1}: ");
                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Número inválido. Tente Novamente.");
                        j--;
                    }
                    else
                        media += notas[i, j];
                }

                medias[i] = media / 3;
            }

            auxiliar = "";
            for(int i = 0; i < 20; i++)
                auxiliar += $"Aluno {i+1}: {medias[i].ToString("N2")} \n";

            MessageBox.Show(auxiliar);
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
                "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
                Total += Alunos[I].Length;

            MessageBox.Show(Total.ToString());
        }


        private void Btn4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string auxiliar = "";
            foreach (string aluno in Alunos)
                if (aluno != "Otávio")
                    auxiliar += aluno + "\n";
            
            MessageBox.Show(auxiliar);
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}

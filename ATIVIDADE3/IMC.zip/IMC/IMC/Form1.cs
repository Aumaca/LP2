namespace IMC
{
    public partial class Form1 : Form
    {
        private double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtPeso.Text, out peso) && Double.TryParse(txtAltura.Text, out altura))
            {
                imc = peso / (altura * altura);
                txtIMC.Text = imc.ToString("F1");

                if (peso < 18.5)
                {
                    txtClassificacao.Text = "MAGREZA";
                    txtGrau.Text = "0";
                }
                else if (peso <= 24.9)
                {
                    txtClassificacao.Text = "NORMAL";
                    txtGrau.Text = "0";
                }
                else if (peso <= 29.9)
                {
                    txtClassificacao.Text = "SOBREPESO";
                    txtGrau.Text = "I";
                }
                else if (peso <= 40)
                {
                    txtClassificacao.Text = "OBESIDADE";
                    txtGrau.Text = "II";
                }
                else
                {
                    txtClassificacao.Text = "OBESIDADE GRAVE";
                    txtGrau.Text = "III";
                }
            }
            else
            {
                txtIMC.Text = "";
                txtClassificacao.Text = "";
                txtGrau.Text = "";

                if (!(Double.TryParse(txtPeso.Text, out peso)) && !(Double.TryParse(txtAltura.Text, out altura)))
                {
                    MessageBox.Show("Peso e altura inv�lidos.", "Dados inv�lidos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPeso.Focus();
                }
                else if (!(Double.TryParse(txtPeso.Text, out peso)))
                {
                    MessageBox.Show("Peso inv�lido.", "Dado inv�lido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPeso.Focus();
                }
                else if (!(Double.TryParse(txtAltura.Text, out altura)))
                {
                    MessageBox.Show("Altura inv�lido.", "Dado inv�lido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtAltura.Focus();
                }
            }
        }

        private string ObterClassificacaoIMC()
        {
            if (peso < 18.5)
            {
                return "MAGREZA";
            }
            else if (peso <= 24.9)
            {
                return "NORMAL";
            }
            else if (peso <= 29.9)
            {
                return "SOBREPESO";
            }
            else if (peso <= 40)
            {
                return "OBESIDADE";
            }
            else
            {
                return "OBESIDADE GRAVE";
            }
        }
    }
}